package mk.finki.ukim.mk.lab.model;// classsin nerde located odlugunu suley


import lombok.AllArgsConstructor;//
import lombok.Data;

import java.util.concurrent.atomic.AtomicLong;

@Data//importira etemk icin getter setter he sey
 // generiri aconsturktor?
public class Event {
    private static final AtomicLong ID_GENERATOR = new AtomicLong(1);  // Auto-increment ID generator

    private Long id;
    String name;
    String description;
    Double popularityScore;
    private Location location;


    public Event(String name, String description, Double popularityScore, Location location) {
        this.id = ID_GENERATOR.getAndIncrement();  // Automatically assign a unique ID
        this.name = name;
        this.description = description;
        this.popularityScore = popularityScore;
        this.location = location;
    }

    // Default constructor
    public Event() {
        this.id = ID_GENERATOR.getAndIncrement();  // Assign an ID in case this constructor is used
    }


}
// data anatocija ile gerek kalmay yazasin getter setterler bununle arka pllanda hazir oli getter steerrler
