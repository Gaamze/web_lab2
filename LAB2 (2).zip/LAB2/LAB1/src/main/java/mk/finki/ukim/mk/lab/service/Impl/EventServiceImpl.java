package mk.finki.ukim.mk.lab.service.Impl;

import mk.finki.ukim.mk.lab.model.Event;
import mk.finki.ukim.mk.lab.model.Location;
import mk.finki.ukim.mk.lab.repository.EventRepository;
import mk.finki.ukim.mk.lab.repository.LocationRepository;
import mk.finki.ukim.mk.lab.service.EventService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventServiceImpl implements EventService {
    private final EventRepository eventRepository;                      //reference yapay burda
                                                                         //inicijalizira olacak sadece 1 kez oda consturcotr sayesinde
    private final LocationRepository repository;

    public EventServiceImpl(EventRepository eventRepository, LocationRepository repository) {
        this.eventRepository = eventRepository;
        this.repository = repository;
    }
        //konsturkor injection insatnca ali em incijalizira edey
    @Override
    public List<Event> listAll() {
        return eventRepository.findAll();
    }
    @Override
    public void saveEvent(String eventname, String description, double popularityScore, Long id) {
        Location location = repository.findById(id);
        eventRepository.addEvent(eventname,description,popularityScore, location);
    }
    @Override
    public List<Event> searchEvents(String text,  int score) {
        return eventRepository.searchEvents(text, score);
    }

    @Override
    public Event getEventById(Long id) {
        return eventRepository.getById(id);
    }

    @Override
    public void editEvent(String eventname, String description, double popularityScore, Long eventId, Long locationId) {
        Event event = eventRepository.getById(eventId);
        Location location = repository.findById(locationId);
        event.setName(eventname);
        event.setDescription(description);
        event.setPopularityScore(popularityScore);
        event.setLocation(location);

        eventRepository.editEvent(event);
    }

    @Override
    public void deleteById(Long id) {
        eventRepository.deleteById(id);
    }

}
